<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\StickyNoteController;
use App\Http\Controllers\ReminderController;

Route::get('/', function () {
    return view('index');
});

Route::get('login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('login', [AuthController::class, 'login']);
Route::get('register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('register', [AuthController::class, 'register']);
Route::post('logout', [AuthController::class, 'logout'])->name('logout');

Route::get('dashboard', function () {
    return view('dashboard');
})->middleware('auth');

Route::get('tasks', [TaskController::class, 'index'])->name('tasks');
Route::resource('tasks', TaskController::class)->middleware('auth');
Route::patch('tasks/{task}/toggle', [TaskController::class, 'toggleCompletion'])->middleware('auth')->name('tasks.toggleCompletion');
Route::post('/tasks', [TaskController::class, 'store'])->name('tasks.store');
Route::get('/dashboard', [TaskController::class, 'urgentTasks'])->name('dashboard');

Route::get('sticky-notes', [StickyNoteController::class, 'index'])->name('notes');
Route::resource('sticky-notes', StickyNoteController::class);

Route::get('reminders', [ReminderController::class, 'index'])->name('reminders');
Route::resource('reminders', ReminderController::class);
Route::patch('reminders/{reminder}/complete', [ReminderController::class, 'complete'])->name('reminders.complete');
