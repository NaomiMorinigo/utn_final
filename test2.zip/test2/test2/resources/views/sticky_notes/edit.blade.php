@extends('header')
@section('styles')
    <link rel="stylesheet" href="{{ asset('css/edit_create.css') }}">
@endsection
@section('content')
    <a href="{{ route('sticky-notes.index') }}" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
    <div class="container mt-4">
        <h2>Editar Nota</h2>
        <form action="{{ route('sticky-notes.update', $stickyNote->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="title">Título</label>
                <input type="text" class="form-control" id="title" name="title" value="{{ $stickyNote->title }}" required>
            </div>
            <div class="form-group">
                <label for="content">Contenido</label>
                <textarea class="form-control" id="content" name="content" rows="4" required>{{ $stickyNote->content }}</textarea>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
@endsection