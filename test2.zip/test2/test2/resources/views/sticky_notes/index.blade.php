@extends('header')
@section('styles')
    <link rel="stylesheet" href="{{ asset('css/sticky.css') }}">
@endsection
@section('content')
<a href="{{ route('dashboard') }}" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
<div class="container">
    <h2>Sticky Notas</h2>
    <a href="{{ route('sticky-notes.create') }}" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Añadir Nueva Nota</a>
    <div class="row">
        @foreach ($stickyNotes as $stickyNote)
        <div class="col-md-4">
            <div class="sticky-note">
                <div class="content">
                    <div class="options">
                        <div class="btn-group dropleft">
                            <button class="btn dropdown-toggle" type="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                              <a class="dropdown-item" href="{{ route('sticky-notes.edit', $stickyNote->id) }}"><i class="fas fa-edit"></i> Editar</a>
                              <form action="{{ route('sticky-notes.destroy', $stickyNote->id) }}" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar esta nota?');">
                                  @csrf
                                  @method('DELETE')
                                  <button class="dropdown-item" type="submit"><i class="fas fa-trash-alt"></i> Borrar</button>
                              </form>
                            </div>
                        </div>
                    </div>
                    <strong>{{ $stickyNote->title }}</strong><br>
                    {!! nl2br(e($stickyNote->content)) !!}
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.options').forEach(function(element) {
            element.addEventListener('click', function() {
                const dropdownMenu = this.querySelector('.dropdown-menu');
                dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
            });
        });

        document.addEventListener('click', function(event) {
            if (!event.target.closest('.options')) {
                document.querySelectorAll('.dropdown-menu').forEach(function(menu) {
                    menu.style.display = 'none';
                });
            }
        });
    });
</script>
@endsection
