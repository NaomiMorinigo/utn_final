@extends('header')
@section('styles')
    <link rel="stylesheet" href="{{ asset('css/dashboard.css') }}">
@endsection
@section('content')
    <div class="container">
    <div class="jumbotron mt-4">
        <h1 class="display-4">Bienvenido, {{ Auth::user()->name }}!</h1>
        <p>Aquí puedes administrar tus notas, ver tareas urgentes y más.</p>
        <a class="btn btn-primary btn-lg" href="{{ route('tasks.index') }}" role="button">Lista de Tareas</a>
        <a class="btn btn-primary btn-lg" href="{{ route('sticky-notes.index') }}" role="button">Muro de Notas</a>
        <a class="btn btn-primary btn-lg" href="{{ route('reminders.index') }}" role="button">Recordatorios</a>
    </div>
    <div class="card">
        <div class="card-header">Tareas Urgentes</div>
        <div class="card-body">
            @if($urgentTasks->isEmpty())
                <p class="card-text">No hay tareas urgentes disponibles.</p>
            @else
                <ul class="list-group">
                    @foreach($urgentTasks as $task)
                        <li class="list-group-item">
                            {{ $task->title }} - 
                            {{ $task->due_date ? \Carbon\Carbon::parse($task->due_date)->format('d/m/Y') : 'Sin fecha de vencimiento' }}
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
</div>
@endsection