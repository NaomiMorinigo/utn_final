@extends('header')
@section('styles')
    <link rel="stylesheet" href="{{ asset('css/edit_create.css') }}">
@endsection
@section('content')
<a href="{{ route('reminders.index') }}" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
<div class="container">
    <h2>Crear Recordatorio</h2>
    <form action="{{ route('reminders.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="title">Título</label>
            <input type="text" class="form-control" id="title" name="title" value="{{ old('title') }}" required>
        </div>
        <div class="form-group">
            <label for="description">Descripción</label>
            <textarea class="form-control" id="description" name="description" rows="4">{{ old('description') }}</textarea>
        </div>
        <div class="form-group">
            <label for="reminder_time">Fecha y Hora</label>
            <input type="datetime-local" class="form-control" id="reminder_time" name="reminder_time" value="{{ old('reminder_time') }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</div>
@endsection
