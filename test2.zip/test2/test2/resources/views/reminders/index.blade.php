@extends('header')
@section('styles')
    <link rel="stylesheet" href="{{ asset('css/reminders.css') }}">
@endsection
@section('content')
    <a href="{{ route('dashboard') }}" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
    <div class="container mt-4">
        <h2 class="mb-4">Lista de Recordatorios</h2>
        <a href="{{ route('reminders.create') }}" class="btn btn-success mb-3">
            <i class="fas fa-plus"></i> Crear Recordatorio
        </a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Fecha y Hora</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($reminders as $reminder)
                <tr>
                    <td>{{ $reminder->title }}</td>
                    <td>{{ $reminder->description }}</td>
                    <td>{{ \Carbon\Carbon::parse($reminder->reminder_time)->format('d/m/Y H:i') }}</td>
                    <td>
                        <a href="{{ route('reminders.edit', $reminder->id) }}" class="btn btn-primary btn-sm">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <form action="{{ route('reminders.destroy', $reminder->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

