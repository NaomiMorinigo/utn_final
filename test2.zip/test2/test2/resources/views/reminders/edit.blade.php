@extends('header')
@section('styles')
    <link rel="stylesheet" href="{{ asset('css/edit_create.css') }}">
@endsection
@section('content')
<a href="{{ route('reminders.index') }}" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
<div class="container">
    <h2>Editar Recordatorio</h2>
    <form action="{{ route('reminders.update', $reminder->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="title">Título</label>
            <input type="text" class="form-control" id="title" name="title" value="{{ old('title', $reminder->title) }}" required>
        </div>
        <div class="form-group">
            <label for="description">Descripción</label>
            <textarea class="form-control" id="description" name="description" rows="4">{{ old('description', $reminder->description) }}</textarea>
        </div>
        <div class="form-group">
            <label for="reminder_time">Fecha y Hora</label>
            <input type="datetime-local" class="form-control" id="reminder_time" name="reminder_time" value="{{ old('reminder_time', $reminder->reminder_time->format('Y-m-d\TH:i')) }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
</div>
@endsection
