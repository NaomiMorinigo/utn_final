@extends('header')
@section('styles')
    <link rel="stylesheet" href="{{ asset('css/tasks.css') }}">
@endsection
@section('content')
<div class="container">
    <a href="{{ route('dashboard') }}" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
    <a href="{{ route('tasks.create') }}" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Añadir Nueva Tarea</a>
    <h2 class="mb-4">Mi Lista de Tareas</h2>
    <ul class="list-group">
        @foreach ($tasks as $task)
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <h5>{{ $task->title }}</h5>
                    <p>{{ $task->description }}</p>
                    <span class="badge badge-{{ $task->completed ? 'success' : 'secondary' }}">
                        {{ $task->completed ? 'Completo' : 'Pendiente' }}
                    </span>
                    <p>
                        <strong>Fecha de Vencimiento:</strong>
                        {{ $task->due_date ? \Carbon\Carbon::parse($task->due_date)->format('d/m/Y') : 'Sin fecha de vencimiento' }}
                    </p>
                </div>
                <div>
                    @if ($task->completed)
                        <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-check"></i> Completado</button>
                    @else
                        <form action="{{ route('tasks.toggleCompletion', $task->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('PATCH')
                            <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Completado</button>
                        </form>
                    @endif
                    <a href="{{ route('tasks.edit', $task->id) }}" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Editar</a>
                    <form action="{{ route('tasks.destroy', $task->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i> Borrar</button>
                    </form>                    
                </div>
            </li>
        @endforeach
    </ul>
</div>
@endsection