@extends('header')
@section('styles')
    <link rel="stylesheet" href="{{ asset('css/edit_create.css') }}">
@endsection
@section('content')
<a href="{{ route('tasks.index') }}" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
<div class="container">
    <h2><i class="fas fa-tasks"></i> Crear Nueva Tarea</h2>
    <form action="{{ route('tasks.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="title">Título</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="form-group">
            <label for="description">Descripción</label>
            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
        <div class="form-group">
            <label for="due_date">Fecha de Vencimiento</label>
            <input type="date" class="form-control" id="due_date" name="due_date">
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="is_urgent" name="is_urgent">
            <label class="form-check-label" for="is_urgent">Marcar como Urgente</label>
        </div>
        <button type="submit" class="btn btn-primary">Crear Tarea</button>
    </form>
</div>
@endsection