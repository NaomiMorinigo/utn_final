<?php

namespace App\Http\Controllers;

use App\Models\Reminder;
use Illuminate\Http\Request;

class ReminderController extends Controller
{
public function index()
{
    $reminders = Reminder::where('is_completed', false)->orderBy('reminder_time')->get();
    return view('reminders.index', compact('reminders'));
}

public function create()
{
    return view('reminders.create');
}

public function store(Request $request)
{
    $validated = $request->validate([
        'title' => 'required|string|max:255',
        'description' => 'nullable|string',
        'reminder_time' => 'required|date',
    ]);

    Reminder::create($validated);
    return redirect()->route('reminders.index');
}

public function edit(Reminder $reminder)
{
    return view('reminders.edit', compact('reminder'));
}

public function update(Request $request, Reminder $reminder)
{
    $validated = $request->validate([
        'title' => 'required|string|max:255',
        'description' => 'nullable|string',
        'reminder_time' => 'required|date',
    ]);

    $reminder->update($validated);
    return redirect()->route('reminders.index');
}

public function destroy(Reminder $reminder)
{
    $reminder->delete();
    return redirect()->route('reminders.index');
}

public function complete(Reminder $reminder)
{
    $reminder->update(['is_completed' => true]);
    return redirect()->route('reminders.index');
}

}
