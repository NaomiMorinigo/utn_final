<?php

namespace App\Http\Controllers;

use App\Models\StickyNote;
use Illuminate\Http\Request;

class StickyNoteController extends Controller
{
    public function index()
    {
        $stickyNotes = StickyNote::all();
        return view('sticky_notes.index', compact('stickyNotes'));
    }

    public function create()
    {
        return view('sticky_notes.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'nullable|string|max:255',
            'content' => 'required|string',
        ]);

        StickyNote::create([
            'title' => $request->title,
            'content' => $request->content,
        ]);

        return redirect()->route('sticky-notes.index')->with('success', 'Sticky Note created successfully.');
    }

    public function edit(StickyNote $stickyNote)
    {
        return view('sticky_notes.edit', compact('stickyNote'));
    }

    public function update(Request $request, StickyNote $stickyNote)
    {
        $request->validate([
            'title' => 'nullable|string|max:255',
            'content' => 'required|string',
        ]);

        $stickyNote->update([
            'title' => $request->title,
            'content' => $request->content,
        ]);

        return redirect()->route('sticky-notes.index')->with('success', 'Sticky Note updated successfully.');
    }

    public function destroy(StickyNote $stickyNote)
    {
        $stickyNote->delete();
        return redirect()->route('sticky-notes.index')->with('success', 'Sticky Note deleted successfully.');
    }
    
    public function show(StickyNote $stickyNote)
    {
        return redirect()->route('sticky-notes.index');
    }
}
