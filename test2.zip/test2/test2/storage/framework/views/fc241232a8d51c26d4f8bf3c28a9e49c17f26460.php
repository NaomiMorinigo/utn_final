
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/edit_create.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
<div class="container">
    <h2><i class="fas fa-edit"></i> Actualizar Tarea</h2>
    <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Título</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title', $task->title)); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Descripción</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo e(old('description', $task->description)); ?></textarea>
        </div>
        <div class="form-group">
            <label for="due_date">Fecha de Vencimiento</label>
            <input type="date" class="form-control" id="due_date" name="due_date" value="<?php echo e(old('due_date', $task->due_date)); ?>">
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="is_urgent" name="is_urgent" <?php echo e(old('is_urgent', $task->is_urgent) ? 'checked' : ''); ?>>
            <label class="form-check-label" for="is_urgent">Marcar como Urgente</label>
        </div>
        <button type="submit" class="btn btn-primary">Actualizar Tarea</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/tasks/edit.blade.php ENDPATH**/ ?>