
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/tasks.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Añadir Nueva Tarea</a>
    <h2 class="mb-4">Mi Lista de Tareas</h2>
    <ul class="list-group">
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <h5><?php echo e($task->title); ?></h5>
                    <p><?php echo e($task->description); ?></p>
                    <span class="badge badge-<?php echo e($task->completed ? 'success' : 'secondary'); ?>">
                        <?php echo e($task->completed ? 'Completo' : 'Pendiente'); ?>

                    </span>
                    <p>
                        <strong>Fecha de Vencimiento:</strong>
                        <?php echo e($task->due_date ? \Carbon\Carbon::parse($task->due_date)->format('d/m/Y') : 'Sin fecha de vencimiento'); ?>

                    </p>
                </div>
                <div>
                    <?php if($task->completed): ?>
                        <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-check"></i> Completado</button>
                    <?php else: ?>
                        <form action="<?php echo e(route('tasks.toggleCompletion', $task->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Completado</button>
                        </form>
                    <?php endif; ?>
                    <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Editar</a>
                    <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i> Borrar</button>
                    </form>                    
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/tasks/index.blade.php ENDPATH**/ ?>