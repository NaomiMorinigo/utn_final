<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planificador</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>To Do List!</h1>
        </header>
        <div class="content">
            <div class="content-text">
                <h2>Notas? Anotalas aquí!</h2>
                <p>Podrás gestionar tus tareas diarias, establecer recordatorios y mantenerte al día con tus compromisos. Añade, edita y elimina con facilidad para nunca olvidar lo que es importante.</p>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-custom">Registrarse</a>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-custom">Login</a>
            </div>
            <div class="content-image">
                <img src="<?php echo e(asset('images/notas.jpg')); ?>" alt="Event Image">
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/index.blade.php ENDPATH**/ ?>