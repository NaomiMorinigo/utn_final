
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/edit_create.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
<div class="container">
    <h2><i class="fas fa-tasks"></i> Crear Nueva Tarea</h2>
    <form action="<?php echo e(route('tasks.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Título</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="form-group">
            <label for="description">Descripción</label>
            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
        <div class="form-group">
            <label for="due_date">Fecha de Vencimiento</label>
            <input type="date" class="form-control" id="due_date" name="due_date">
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="is_urgent" name="is_urgent">
            <label class="form-check-label" for="is_urgent">Marcar como Urgente</label>
        </div>
        <button type="submit" class="btn btn-primary">Crear Tarea</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/tasks/create.blade.php ENDPATH**/ ?>