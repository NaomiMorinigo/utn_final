
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/reminders.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
    <div class="container mt-4">
        <h2 class="mb-4">Lista de Recordatorios</h2>
        <a href="<?php echo e(route('reminders.create')); ?>" class="btn btn-success mb-3">
            <i class="fas fa-plus"></i> Crear Recordatorio
        </a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Fecha y Hora</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($reminder->title); ?></td>
                    <td><?php echo e($reminder->description); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($reminder->reminder_time)->format('d/m/Y H:i')); ?></td>
                    <td>
                        <a href="<?php echo e(route('reminders.edit', $reminder->id)); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <form action="<?php echo e(route('reminders.destroy', $reminder->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/reminders/index.blade.php ENDPATH**/ ?>