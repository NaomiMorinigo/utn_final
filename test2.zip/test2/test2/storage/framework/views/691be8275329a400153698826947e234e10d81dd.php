<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Details</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2><?php echo e($project->name); ?></h2>
    <p><?php echo e($project->description); ?></p>
    <ul class="list-group">
        <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <h5><?php echo e($task->title); ?></h5>
                    <p><?php echo e($task->description); ?></p>
                    <span class="badge badge-<?php echo e($task->completed ? 'success' : 'secondary'); ?>">
                        <?php echo e($task->completed ? 'Completed' : 'Pending'); ?>

                    </span>
                </div>
                <div>
                    <?php if($task->completed): ?>
                        <button class="btn btn-secondary btn-sm" disabled>Completed</button>
                    <?php else: ?>
                        <form action="<?php echo e(route('project-tasks.update', $task->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="completed" value="1">
                            <button type="submit" class="btn btn-success btn-sm">Mark as Completed</button>
                        </form>
                    <?php endif; ?>
                    <a href="<?php echo e(route('project-tasks.edit', $task->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('project-tasks.destroy', $task->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/project_tasks/show.blade.php ENDPATH**/ ?>