
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/edit_create.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('reminders.index')); ?>" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i></a>
<div class="container">
    <h2>Editar Recordatorio</h2>
    <form action="<?php echo e(route('reminders.update', $reminder->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Título</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title', $reminder->title)); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Descripción</label>
            <textarea class="form-control" id="description" name="description" rows="4"><?php echo e(old('description', $reminder->description)); ?></textarea>
        </div>
        <div class="form-group">
            <label for="reminder_time">Fecha y Hora</label>
            <input type="datetime-local" class="form-control" id="reminder_time" name="reminder_time" value="<?php echo e(old('reminder_time', $reminder->reminder_time->format('Y-m-d\TH:i'))); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/reminders/edit.blade.php ENDPATH**/ ?>