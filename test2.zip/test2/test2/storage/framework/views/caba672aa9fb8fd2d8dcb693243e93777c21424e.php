
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="jumbotron mt-4">
        <h1 class="display-4">Bienvenido, <?php echo e(Auth::user()->name); ?>!</h1>
        <p>Aquí puedes administrar tus notas, ver tareas urgentes y más.</p>
        <a class="btn btn-primary btn-lg" href="<?php echo e(route('tasks.index')); ?>" role="button">Lista de Tareas</a>
        <a class="btn btn-primary btn-lg" href="<?php echo e(route('sticky-notes.index')); ?>" role="button">Muro de Notas</a>
        <a class="btn btn-primary btn-lg" href="<?php echo e(route('reminders.index')); ?>" role="button">Recordatorios</a>
    </div>
    <div class="card">
        <div class="card-header">Tareas Urgentes</div>
        <div class="card-body">
            <?php if($urgentTasks->isEmpty()): ?>
                <p class="card-text">No hay tareas urgentes disponibles.</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $urgentTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php echo e($task->title); ?> - 
                            <?php echo e($task->due_date ? \Carbon\Carbon::parse($task->due_date)->format('d/m/Y') : 'Sin fecha de vencimiento'); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test2\test2\resources\views/dashboard.blade.php ENDPATH**/ ?>